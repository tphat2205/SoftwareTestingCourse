# HW02 - Domain Testing & Boundary Value Analysis on EShop

## 1. Self-Assessment Table

| **No.** | **Criteria**                                                          | **Grade** | **Self-Assessed Grade** |
| ------- | --------------------------------------------------------------------- | --------- | ----------------------- |
| **1**   | Feature FR-06: Xem chi tiết sản phẩm (Domain + Boundary)              | 25        | 25                      |
| **2**   | Feature FR-10: Order state machine (Domain + Boundary)                | 25        | 25                      |
| **3**   | Feature FR-15: Product management (CRUD) (Domain + Boundary)          | 25        | 25                      |
| **4**   | Feature FR-05: Product listing and search (Mobile, Domain + Boundary) | 15        | 15                      |
| **5**   | Agent Skills                                                          | 10        | 10                      |
|         | **Total**                                                             | **100**   | **100**                 |

## 2. Test Summary Report

| Metric                                    | Count |
| ----------------------------------------- | ----- |
| **Number of features tested**             | 4     |
| **Number of test cases designed**         | 45    |
| **Number of test cases executed**         | 45    |
| **Number of test cases passed**           | 27    |
| **Number of test cases failed**           | 18    |
| **Number of test cases not yet executed** | 0     |
| **Number of bugs reported**               | 15    |

### Breakdown by Feature

| Feature                                        | TC Designed | TC Executed | TC Passed | TC Failed | Bugs Reported |
| ---------------------------------------------- | :---------: | :---------: | :-------: | :-------: | :-----------: |
| **FR-06:** Xem chi tiết sản phẩm               |      8      |      8      |     0     |     8     |       5       |
| **FR-10:** Order state machine                 |     16      |     16      |    13     |     3     |       2       |
| **FR-15:** Product management (CRUD)           |     12      |     12      |     8     |     4     |       3       |
| **FR-05:** Product listing and search (Mobile) |      9      |      9      |     6     |     3     |       5       |
| **Total**                                      |   **45**    |   **45**    |  **27**   |  **18**   |    **15**     |

## 3. Demo Videos

- **Agent Skill Demo Video (Domain Testing & BVA):** https://youtu.be/LnJAqokKQds
